import React from 'react';
import Link from 'next/link';

// A simple, clean SVG logo for ReWear.
// It combines a recycling symbol with a shirt icon.
export const Logo = ({ className = "h-10 w-auto" }) => {
  return (
    <Link href="/" className="flex items-center space-x-2 text-gray-800 hover:text-indigo-600">
        <svg className={className} viewBox="0 0 160 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14.5 15.5L10 20L14.5 24.5M25.5 15.5L30 20L25.5 24.5M20 10V30" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 20H5C3.34315 20 2 21.3431 2 23V28C2 29.6569 3.34315 31 5 31H35C36.6569 31 38 29.6569 38 28V23C38 21.3431 36.6569 20 35 20H30" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
            <text x="45" y="29" fontFamily="sans-serif" fontSize="24" fontWeight="bold" fill="currentColor">ReWear</text>
        </svg>
    </Link>
  );
};
