import React from 'react';
import Link from 'next/link';

export default function ItemCard({ item, onRelist }) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden group transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 flex flex-col">
      <Link href={`/item/${item.id}`} className="cursor-pointer">
        <div className="w-full h-64 bg-gray-200">
            <img src={item.imageUrls?.[0] || 'https://placehold.co/400x400/e2e8f0/cbd5e0?text=ReWear'} alt={item.title} className="w-full h-full object-cover" />
        </div>
        <div className="p-4">
            <h3 className="text-lg font-semibold truncate group-hover:text-indigo-600">{item.title}</h3>
            <p className="text-sm text-gray-500">{item.category}</p>
            <div className="mt-2 flex justify-between items-center">
                <span className={`text-xs font-bold uppercase px-2 py-1 rounded-full ${
                    item.status === 'available' ? 'bg-green-200 text-green-800' :
                    item.status === 'pending' ? 'bg-yellow-200 text-yellow-800' : 'bg-gray-200 text-gray-800'
                }`}>{item.status}</span>
                {item.pointsValue && <span className="text-lg font-bold text-indigo-600">{item.pointsValue} pts</span>}
            </div>
        </div>
      </Link>
      {onRelist && item.status === 'redeemed' && (
        <div className="p-4 pt-0 mt-auto">
            <button onClick={onRelist} className="w-full bg-blue-500 text-white font-semibold py-2 rounded-lg hover:bg-blue-600">
                Relist This Item
            </button>
        </div>
      )}
    </div>
  );
}
