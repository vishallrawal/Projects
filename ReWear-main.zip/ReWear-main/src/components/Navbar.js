import React from 'react';
import Link from 'next/link';
import { useAuth } from '../context/AuthContext';
import { Logo } from './ui/Logo';

export default function Navbar() {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();

  return (
    <header className="bg-white shadow-md fixed w-full top-0 z-40">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Logo />
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-600 hover:text-indigo-600 transition cursor-pointer">Browse</Link>
            {isAuthenticated && <Link href="/add-item" className="text-gray-600 hover:text-indigo-600 transition cursor-pointer">List an Item</Link>}
            {isAdmin && <Link href="/admin" className="text-red-500 hover:text-red-700 transition cursor-pointer font-semibold">Admin Panel</Link>}
          </nav>
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-indigo-600 hidden sm:inline">{user?.points || 0} Points</span>
                </div>
                <Link href="/dashboard" className="p-2 rounded-full hover:bg-gray-100 font-medium">
                  Dashboard
                </Link>
                <button onClick={logout} className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-300">
                  Sign Out
                </button>
              </>
            ) : (
              <Link href="/login" className="bg-indigo-600 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700">
                Login / Sign Up
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
