import React, { createContext, useContext, useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { Spinner } from '../components/ui/Spinner';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const storedUser = sessionStorage.getItem('rewear-user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await response.json();
    if (response.ok) {
      setUser(data.user);
      sessionStorage.setItem('rewear-user', JSON.stringify(data.user));
      return { success: true };
    }
    return { success: false, message: data.message };
  };

  const register = async (userData) => {
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData),
    });
    const data = await response.json();
    if (response.ok) {
      setUser(data.user);
      sessionStorage.setItem('rewear-user', JSON.stringify(data.user));
      return { success: true };
    }
    return { success: false, message: data.message };
  };

  const logout = () => {
    setUser(null);
    sessionStorage.removeItem('rewear-user');
    router.push('/login');
  };

  const updateUser = (updatedUserData) => {
    setUser(updatedUserData);
    sessionStorage.setItem('rewear-user', JSON.stringify(updatedUserData));
  };

  const value = {
    user,
    isAuthenticated: !!user,
    isAdmin: user?.isAdmin || false,
    loading,
    login,
    register,
    logout,
    updateUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {loading ? <div className="h-screen flex items-center justify-center"><Spinner /></div> : children}
    </AuthContext.Provider>
  );
}
