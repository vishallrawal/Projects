import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { useAuth } from '../context/AuthContext';
import { useModal } from '../context/ModalContext';
import ItemCard from '../components/ItemCard';
import { Spinner } from '../components/ui/Spinner';
import { Icon } from '../components/ui/Icon';

export default function DashboardPage() {
    const { user, isAuthenticated, loading, updateUser } = useAuth();
    const router = useRouter();
    const { showModal } = useModal();
    const [myItems, setMyItems] = useState([]);
    const [redeemedItems, setRedeemedItems] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [pointsToBuy, setPointsToBuy] = useState(100);
    const [isBuyPointsModalOpen, setIsBuyPointsModalOpen] = useState(false);
    const [view, setView] = useState('listed');

    useEffect(() => {
        if (!loading && !isAuthenticated) {
            router.push('/login');
            return;
        }
        if (user && user.id) {
            fetchDashboardData();
        } else if (!loading) {
            setIsLoading(false);
        }
    }, [user, isAuthenticated, loading, router]);

    const fetchDashboardData = async () => {
        setIsLoading(true);
        try {
            const [listedRes, redeemedRes] = await Promise.all([
                fetch(`/api/users/${user.id}/items`),
                fetch(`/api/users/${user.id}/redeemed`)
            ]);
            if (listedRes.ok) setMyItems(await listedRes.json());
            if (redeemedRes.ok) setRedeemedItems(await redeemedRes.json());
        } catch (error) {
            console.error("Error fetching dashboard data:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleBuyPoints = async () => {
        try {
            const response = await fetch('/api/points/buy', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId: user.id, amount: pointsToBuy }),
            });
            const data = await response.json();
            if (response.ok) {
                updateUser(data.user);
                setIsBuyPointsModalOpen(false);
                showModal(`${pointsToBuy} points added successfully!`);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            showModal(`Error: ${error.message}`);
        }
    };
    
    const handleRelist = async (itemId) => {
        try {
            const response = await fetch('/api/items/relist', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ itemId, currentOwnerId: user.id }),
            });
            const data = await response.json();
            if (response.ok) {
                showModal(data.message);
                fetchDashboardData(); // Refresh data
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            showModal(`Error: ${error.message}`);
        }
    };

    if (isLoading) return <div className="h-screen w-full flex items-center justify-center"><Spinner /></div>;
    if (!isAuthenticated) return null;
    
    const soldItemsCount = myItems.filter(item => item.status === 'redeemed').length;

    return (
        <>
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Main Content */}
                    <div className="lg:col-span-2">
                        <div className="flex justify-between items-center mb-6">
                            <h1 className="text-3xl font-bold">My Dashboard</h1>
                            <Link href="/add-item" className="bg-indigo-600 text-white font-semibold py-2 px-5 rounded-lg hover:bg-indigo-700 flex items-center gap-2">
                                <Icon path="M12 4.5v15m7.5-7.5h-15" className="w-5 h-5"/> Add New Item
                            </Link>
                        </div>
                        <div className="bg-white p-6 rounded-xl shadow-md mb-8">
                            <h2 className="text-xl font-bold mb-4">My Stats</h2>
                            <div className="grid grid-cols-3 gap-4 text-center">
                                <div className="bg-gray-100 p-4 rounded-lg"><p className="text-2xl font-bold">{myItems.length}</p><p className="text-sm text-gray-600">Items Listed</p></div>
                                <div className="bg-gray-100 p-4 rounded-lg"><p className="text-2xl font-bold">{soldItemsCount}</p><p className="text-sm text-gray-600">Items Sold</p></div>
                                <div className="bg-gray-100 p-4 rounded-lg"><p className="text-2xl font-bold">{redeemedItems.length}</p><p className="text-sm text-gray-600">Items Acquired</p></div>
                            </div>
                        </div>
                        <div>
                            <div className="border-b border-gray-200 mb-4">
                                <nav className="-mb-px flex space-x-8">
                                    <button onClick={() => setView('listed')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${view === 'listed' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>My Listings</button>
                                    <button onClick={() => setView('redeemed')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${view === 'redeemed' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>My Acquired Items</button>
                                </nav>
                            </div>
                            {view === 'listed' && (
                                myItems.length > 0 ? (
                                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">{myItems.map(item => <ItemCard key={item.id} item={item} />)}</div>
                                ) : ( <div className="text-center text-gray-500 py-10 bg-gray-100 rounded-lg"><p>You haven't listed any items yet.</p></div> )
                            )}
                             {view === 'redeemed' && (
                                redeemedItems.length > 0 ? (
                                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                                        {redeemedItems.map(item => <ItemCard key={item.id} item={item} onRelist={() => handleRelist(item.id)} />)}
                                    </div>
                                ) : ( <div className="text-center text-gray-500 py-10 bg-gray-100 rounded-lg"><p>You haven't acquired any items yet.</p></div> )
                            )}
                        </div>
                    </div>
                    {/* Sidebar */}
                    <div className="space-y-8">
                        <div className="bg-white p-6 rounded-xl shadow-md">
                            <div className="flex items-center gap-4 mb-4">
                                <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 text-2xl font-bold">{user?.fullName?.charAt(0) || user?.email?.charAt(0)}</div>
                                <div><h3 className="font-bold text-lg">{user?.fullName}</h3><p className="text-sm text-gray-500">{user?.email}</p></div>
                            </div>
                            <Link href="/settings" className="w-full text-center block bg-gray-200 text-gray-800 font-semibold py-2 px-4 rounded-lg hover:bg-gray-300">Account Settings</Link>
                        </div>
                        <div className="bg-white p-6 rounded-xl shadow-md">
                            <h3 className="font-bold text-lg mb-2">My Points</h3>
                            <p className="text-4xl font-bold text-indigo-600 mb-4">{user?.points || 0}</p>
                            <button onClick={() => setIsBuyPointsModalOpen(true)} className="w-full bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600">Buy More Points</button>
                        </div>
                    </div>
                </div>
            </div>
            {isBuyPointsModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white p-8 rounded-lg shadow-xl max-w-sm w-full">
                        <h2 className="text-2xl font-bold mb-4">Buy Points</h2>
                        <div className="p-4 bg-yellow-100 text-yellow-800 rounded-md text-sm mb-4">
                            <strong>Note:</strong> Real payments are not configured. This will add points to your account for free for demonstration purposes.
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Points to Add</label>
                            <input type="number" value={pointsToBuy} onChange={e => setPointsToBuy(Number(e.target.value))} min="10" step="10" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
                        </div>
                        <p className="text-center text-gray-600 my-4">Cost: <span className="font-bold">₹{pointsToBuy / 10}</span> (at ₹1 for 10 points)</p>
                        <div className="flex justify-end gap-4">
                            <button onClick={() => setIsBuyPointsModalOpen(false)} className="py-2 px-4 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">Cancel</button>
                            <button onClick={handleBuyPoints} className="py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700">Confirm Purchase</button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
