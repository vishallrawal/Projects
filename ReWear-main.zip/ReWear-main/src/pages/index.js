import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '../context/AuthContext';
import ItemCard from '../components/ItemCard';
import { Spinner } from '../components/ui/Spinner';

export default function LandingPage() {
  const { isAuthenticated } = useAuth(); // Get the user's authentication status
  const [featuredItems, setFeaturedItems] = useState([]);
  const [recentItems, setRecentItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchItems() {
      try {
        const response = await fetch('/api/items');
        if (!response.ok) throw new Error("Could not fetch items");
        const items = await response.json();
        const availableItems = items.filter(item => item.status === 'available');
        
        setFeaturedItems(availableItems.filter(item => item.isFeatured));
        setRecentItems(availableItems.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));

      } catch (error) {
        console.error("Failed to fetch items:", error);
      } finally {
        setIsLoading(false);
      }
    }
    fetchItems();
  }, []);

  return (
    <div>
      <section className="bg-indigo-600 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <h1 className="text-5xl md:text-6xl font-extrabold leading-tight">Give Your Clothes a Second Life</h1>
          <p className="mt-4 text-lg md:text-xl max-w-3xl mx-auto text-indigo-200">Join the ReWear community to swap, share, and refresh your wardrobe sustainably. Reduce waste, save money, and discover unique styles.</p>
          <div className="mt-8 flex justify-center gap-4 flex-wrap">
            {/* This link is now dynamic. It goes to /add-item if logged in, otherwise to /login. */}
            <Link href={isAuthenticated ? '/add-item' : '/login'} className="bg-white text-indigo-600 font-bold py-3 px-8 rounded-full text-lg hover:bg-indigo-100 transition-transform transform hover:scale-105">
              Start Swapping
            </Link>
            <a href="#all-items" className="border-2 border-white font-bold py-3 px-8 rounded-full text-lg hover:bg-white hover:text-indigo-600 transition-transform transform hover:scale-105">
              Browse Items
            </a>
          </div>
        </div>
      </section>
      
      {isLoading ? <div className="py-16 flex justify-center"><Spinner /></div> : (
        <>
          {featuredItems.length > 0 && (
            <section id="featured-items" className="py-16 bg-indigo-50">
              <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-3xl font-bold text-center mb-10">Featured Items</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-8">
                    {featuredItems.map(item => <ItemCard key={item.id} item={item} />)}
                </div>
              </div>
            </section>
          )}

          <section id="all-items" className="py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <h2 className="text-3xl font-bold text-center mb-10">All Items</h2>
              {recentItems.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-8">
                      {recentItems.map(item => <ItemCard key={item.id} item={item} />)}
                  </div>
              ) : (
                  <p className="text-center text-gray-500">No items available right now. Be the first to list something!</p>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
}
