import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default function handler(req, res) {
  const db = readDB();

  if (req.method === 'GET') {
    res.status(200).json(db.items);
  } else if (req.method === 'PUT') {
    const { itemId, ...updates } = req.body;
    const itemIndex = db.items.findIndex(item => item.id === itemId);

    if (itemIndex === -1) {
      return res.status(404).json({ message: 'Item not found' });
    }

    const allowedUpdates = ['title', 'description', 'category', 'size', 'condition', 'pointsValue', 'status', 'isFeatured'];
    Object.keys(updates).forEach(key => {
        if(allowedUpdates.includes(key)) {
            db.items[itemIndex][key] = updates[key];
        }
    });

    writeDB(db);
    res.status(200).json(db.items[itemIndex]);
  } else {
    res.status(405).json({ message: 'Method Not Allowed' });
  }
}
