import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default function handler(req, res) {
  const db = readDB();

  if (req.method === 'GET') {
    const users = db.users.map(({ password, ...user }) => user);
    res.status(200).json(users);
  } else if (req.method === 'PUT') {
    const { userId, ...updates } = req.body;
    const userIndex = db.users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
      return res.status(404).json({ message: 'User not found' });
    }

    db.users[userIndex] = { ...db.users[userIndex], ...updates };
    
    writeDB(db);
    const { password, ...updatedUser } = db.users[userIndex];
    res.status(200).json(updatedUser);

  } else if (req.method === 'DELETE') {
    const { userId } = req.body;
    const initialUserCount = db.users.length;
    db.users = db.users.filter(u => u.id !== userId);
    if (db.users.length === initialUserCount) {
        return res.status(404).json({ message: 'User not found' });
    }
    writeDB(db);
    res.status(200).json({ message: 'User deleted successfully' });
  } else {
    res.status(405).json({ message: 'Method Not Allowed' });
  }
}
