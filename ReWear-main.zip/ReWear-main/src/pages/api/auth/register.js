import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const { email, password, fullName, phoneNumber, shippingAddress } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  try {
    const db = readDB();
    const existingUser = db.users.find(u => u.email === email);

    if (existingUser) {
      return res.status(409).json({ message: 'User with this email already exists' });
    }

    const newUser = {
      id: `user-${Date.now()}`,
      fullName: fullName || '',
      email,
      password,
      phoneNumber: phoneNumber || '',
      shippingAddress: shippingAddress || '',
      points: 50,
      isAdmin: false,
    };

    db.users.push(newUser);
    writeDB(db);

    const { password: _, ...userWithoutPassword } = newUser;
    res.status(201).json({ user: userWithoutPassword });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error });
  }
}
