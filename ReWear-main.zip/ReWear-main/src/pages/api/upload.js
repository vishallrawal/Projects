import { formidable } from 'formidable';
import fs from 'fs';
import path from 'path';

export const config = {
  api: {
    bodyParser: false,
  },
};

const uploadDir = path.join(process.cwd(), 'public', 'uploads');

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const form = formidable({
    uploadDir,
    keepExtensions: true,
    filename: (name, ext, part, form) => {
      return `${name}-${Date.now()}${ext}`;
    }
  });

  try {
    const [fields, files] = await form.parse(req);
    
    if (!files.images) {
      return res.status(400).json({ message: 'No image file uploaded' });
    }

    const imageFiles = Array.isArray(files.images) ? files.images : [files.images];
    
    const uploadedPaths = imageFiles.map(file => `/uploads/${path.basename(file.filepath)}`);

    res.status(200).json({ message: 'Files uploaded successfully', paths: uploadedPaths });

  } catch (error) {
    console.error('File upload error:', error);
    res.status(500).json({ message: 'Error uploading files', error: error.message });
  }
}
