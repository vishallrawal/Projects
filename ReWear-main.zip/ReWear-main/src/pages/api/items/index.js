import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default function handler(req, res) {
  if (req.method === 'GET') {
    try {
      const db = readDB();
      const availableItems = db.items.filter(item => item.status === 'available' || item.status === 'pending');
      res.status(200).json(availableItems);
    } catch (error) {
      res.status(500).json({ message: 'Error reading database', error });
    }
  } else if (req.method === 'POST') {
    try {
      const db = readDB();
      const newItem = {
        id: (db.items.length + 1).toString(),
        ...req.body,
        status: 'pending',
        createdAt: new Date().toISOString(),
      };
      db.items.push(newItem);
      writeDB(db);
      res.status(201).json(newItem);
    } catch (error) {
      res.status(500).json({ message: 'Error writing to database', error });
    }
  } else {
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
