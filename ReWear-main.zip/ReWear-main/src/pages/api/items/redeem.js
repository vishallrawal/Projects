import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const { itemId, buyerId } = req.body;

  if (!itemId || !buyerId) {
    return res.status(400).json({ message: 'Item ID and Buyer ID are required' });
  }

  try {
    const db = readDB();
    const itemIndex = db.items.findIndex(item => item.id === itemId);
    const buyerIndex = db.users.findIndex(user => user.id === buyerId);

    if (itemIndex === -1) return res.status(404).json({ message: 'Item not found' });
    if (buyerIndex === -1) return res.status(404).json({ message: 'Buyer not found' });

    const item = db.items[itemIndex];
    const buyer = db.users[buyerIndex];

    if (item.status !== 'available') {
      return res.status(400).json({ message: 'Item is not available for redemption' });
    }
    if (buyer.points < item.pointsValue) {
      return res.status(400).json({ message: 'Insufficient points' });
    }
    if (item.uploaderId === buyer.id) {
        return res.status(400).json({ message: 'Cannot redeem your own item' });
    }

    const sellerIndex = db.users.findIndex(user => user.id === item.uploaderId);

    buyer.points -= item.pointsValue;
    if (sellerIndex !== -1) {
      db.users[sellerIndex].points += item.pointsValue;
    }
    item.status = 'redeemed';
    item.newOwnerId = buyerId;

    db.users[buyerIndex] = buyer;
    db.items[itemIndex] = item;
    
    writeDB(db);

    const { password, ...buyerWithoutPassword } = buyer;
    res.status(200).json({ message: 'Redemption successful!', user: buyerWithoutPassword });

  } catch (error) {
    console.error('Redemption Error:', error);
    res.status(500).json({ message: 'Server error during redemption' });
  }
}
