import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const { itemId, currentOwnerId } = req.body;
  const db = readDB();
  const itemIndex = db.items.findIndex(item => item.id === itemId);

  if (itemIndex === -1) {
    return res.status(404).json({ message: 'Item not found' });
  }

  const item = db.items[itemIndex];
  if (item.status !== 'redeemed' || item.newOwnerId !== currentOwnerId) {
    return res.status(403).json({ message: 'You are not the owner of this item or it cannot be relisted.' });
  }

  item.status = 'available';
  item.uploaderId = currentOwnerId;
  delete item.newOwnerId;

  db.items[itemIndex] = item;
  writeDB(db);

  res.status(200).json({ message: 'Item relisted successfully!', item });
}
