import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default function handler(req, res) {
  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const db = readDB();
      const item = db.items.find(item => item.id === id);
      
      if (item) {
        const uploader = db.users.find(user => user.id === item.uploaderId);
        const itemWithUploader = { ...item, uploaderEmail: uploader ? uploader.email : 'Unknown' };
        res.status(200).json(itemWithUploader);
      } else {
        res.status(404).json({ message: 'Item not found' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Error reading database', error });
    }
  } else if (req.method === 'PUT') {
    // This is the new, corrected logic to handle saving updates.
    try {
        const db = readDB();
        const itemIndex = db.items.findIndex(item => item.id === id);

        if (itemIndex === -1) {
            return res.status(404).json({ message: 'Item not found' });
        }
        
        const updatedItemData = req.body;
        
        db.items[itemIndex] = { ...updatedItemData, id: id };
        
        writeDB(db);
        
        res.status(200).json(db.items[itemIndex]);
    } catch (error) {
        console.error("Update Item API Error:", error);
        res.status(500).json({ message: 'Error updating item', error: error.message });
    }
  } else {
    res.setHeader('Allow', ['GET', 'PUT']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
