import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

export default function handler(req, res) {
  const { userId } = req.query;

  if (req.method === 'GET') {
    try {
      const db = readDB();
      const user = db.users.find(u => u.id === userId);

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const listedItems = db.items.filter(item => item.uploaderId === userId);
      const soldItems = listedItems.filter(item => item.status === 'redeemed');
      const acquiredItems = db.items.filter(item => item.newOwnerId === userId);

      const { password, ...userWithoutPassword } = user;

      res.status(200).json({
        user: userWithoutPassword,
        listedItems,
        soldItems,
        acquiredItems,
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  } else {
    res.status(405).json({ message: 'Method Not Allowed' });
  }
}
