import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default function handler(req, res) {
  const { userId } = req.query;

  if (req.method === 'PUT') {
    const { fullName, shippingAddress, phoneNumber } = req.body;
    const db = readDB();
    const userIndex = db.users.findIndex(u => u.id === userId);

    if (userIndex === -1) {
      return res.status(404).json({ message: 'User not found' });
    }

    db.users[userIndex] = { 
      ...db.users[userIndex], 
      fullName, 
      shippingAddress,
      phoneNumber 
    };
    writeDB(db);

    const { password, ...updatedUser } = db.users[userIndex];
    res.status(200).json(updatedUser);
  } else {
    res.status(405).json({ message: 'Method Not Allowed' });
  }
}
