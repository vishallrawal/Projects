import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  try {
    const fileContent = fs.readFileSync(dbPath, 'utf-8');
    return JSON.parse(fileContent);
  } catch (error) {
    console.error("Error reading the database file:", error);
    return { users: [], items: [] };
  }
}

export default function handler(req, res) {
  const { userId } = req.query;

  if (req.method === 'GET') {
    try {
      const db = readDB();
      const userItems = db.items.filter(item => item.uploaderId === userId);
      res.status(200).json(userItems);
    } catch (error) {
      res.status(500).json({ message: 'Server error while fetching user items' });
    }
  } else {
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
