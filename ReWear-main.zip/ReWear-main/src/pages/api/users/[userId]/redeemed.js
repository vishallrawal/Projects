import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'data', 'db.json');

function readDB() {
  const fileContent = fs.readFileSync(dbPath, 'utf-8');
  return JSON.parse(fileContent);
}

export default function handler(req, res) {
  const { userId } = req.query;

  if (req.method === 'GET') {
    const db = readDB();
    const redeemedItems = db.items.filter(item => item.status === 'redeemed' && item.newOwnerId === userId);
    res.status(200).json(redeemedItems);
  } else {
    res.status(405).json({ message: 'Method Not Allowed' });
  }
}
