import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../context/AuthContext';
import { useModal } from '../../context/ModalContext';
import { Spinner } from '../../components/ui/Spinner';
import { Icon } from '../../components/ui/Icon';

export default function EditItemPage() {
    const { user, isAuthenticated, isAdmin, loading } = useAuth();
    const router = useRouter();
    const { id } = router.query;
    const { showModal } = useModal();

    const [item, setItem] = useState(null);
    const [imageFiles, setImageFiles] = useState([]);
    const [existingImageUrls, setExistingImageUrls] = useState([]);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!loading && !isAuthenticated) router.push('/login');
        if (id && isAuthenticated) fetchItemData();
    }, [id, isAuthenticated, loading]);

    const fetchItemData = async () => {
        try {
            const res = await fetch(`/api/items/${id}`);
            if (!res.ok) throw new Error('Item not found');
            const data = await res.json();
            if (user.id !== data.uploaderId && !isAdmin) {
                 showModal("You don't have permission to edit this item.");
                 router.push('/');
                 return;
            }
            setItem(data);
            setExistingImageUrls(data.imageUrls || []);
        } catch (error) {
            showModal(error.message);
            router.push('/');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleChange = (e) => {
        const { name, value } = e.target;
        setItem(prev => ({ ...prev, [name]: value }));
    };

    const handleImageChange = (e) => {
        if (e.target.files) {
            const files = Array.from(e.target.files);
            setImageFiles(prev => [...prev, ...files]);
        }
    };

    const removeExistingImage = (urlToRemove) => {
        setExistingImageUrls(prev => prev.filter(url => url !== urlToRemove));
    };
    
    const removeNewImage = (indexToRemove) => {
        setImageFiles(prev => prev.filter((_, index) => index !== indexToRemove));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (existingImageUrls.length === 0 && imageFiles.length === 0) {
            showModal("Please add at least one image.");
            return;
        }
        setIsSubmitting(true);
        try {
            let newlyUploadedPaths = [];
            if (imageFiles.length > 0) {
                const formData = new FormData();
                imageFiles.forEach(file => formData.append('images', file));
                
                const uploadRes = await fetch('/api/upload', { method: 'POST', body: formData });
                if (!uploadRes.ok) throw new Error('Image upload failed');
                
                const uploadData = await uploadRes.json();
                newlyUploadedPaths = uploadData.paths;
            }

            const finalImageUrls = [...existingImageUrls, ...newlyUploadedPaths];
            const updatedItem = { ...item, imageUrls: finalImageUrls };

            const response = await fetch(`/api/items/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedItem),
            });
            if (!response.ok) throw new Error('Failed to update item');
            
            showModal('Item updated successfully!');
            router.push(`/item/${id}`);
        } catch (error) {
            showModal(`Error: ${error.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isLoading || !item) return <div className="h-screen flex items-center justify-center"><Spinner /></div>;

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-lg">
                <h1 className="text-3xl font-bold mb-6">Edit Item</h1>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Item Images</label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                            {existingImageUrls.map((url) => (
                                <div key={url} className="relative group"><img src={url} className="w-full h-24 object-cover rounded-md"/><button type="button" onClick={() => removeExistingImage(url)} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 leading-none text-xs w-5 h-5 flex items-center justify-center">&times;</button></div>
                            ))}
                             {imageFiles.map((file, index) => (
                                <div key={index} className="relative group"><img src={URL.createObjectURL(file)} className="w-full h-24 object-cover rounded-md"/><button type="button" onClick={() => removeNewImage(index)} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 leading-none text-xs w-5 h-5 flex items-center justify-center">&times;</button></div>
                            ))}
                        </div>
                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                            <div className="space-y-1 text-center"><Icon path="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" className="mx-auto h-12 w-12 text-gray-400" /><label htmlFor="file-upload" className="cursor-pointer font-medium text-indigo-600 hover:text-indigo-500"><span>Add more images</span><input id="file-upload" type="file" multiple accept="image/*" onChange={handleImageChange} className="sr-only" /></label></div>
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><label className="block text-sm font-medium text-gray-700">Title</label><input type="text" name="title" value={item.title || ''} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm" /></div>
                        <div><label className="block text-sm font-medium text-gray-700">Points Value</label><input type="number" name="pointsValue" value={item.pointsValue || 0} onChange={e => setItem(prev => ({...prev, pointsValue: Number(e.target.value)}))} min="0" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm" /></div>
                        <div className="md:col-span-2"><label className="block text-sm font-medium text-gray-700">Description</label><textarea name="description" value={item.description || ''} onChange={handleChange} rows="4" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"></textarea></div>
                    </div>
                    <div className="flex justify-end gap-4"><button type="button" onClick={() => router.back()} className="py-2 px-6 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">Cancel</button><button type="submit" disabled={isSubmitting} className="py-2 px-6 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300">{isSubmitting ? 'Saving...' : 'Save Changes'}</button></div>
                </form>
            </div>
        </div>
    );
}
