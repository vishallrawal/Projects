import { Html, Head, Main, NextScript } from "next/document";

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        {/* Add the custom SVG favicon */}
        <link
          rel="icon"
          href='data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path d="M40 50 L30 60 L40 70 M60 50 L70 60 L60 70 M50 40 V80" stroke="%234f46e5" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" fill="none"/><path d="M30 60 H20 C15 60 10 65 10 70 V80 C10 85 15 90 20 90 H80 C85 90 90 85 90 80 V70 C90 65 85 60 80 60 H70" stroke="%234f46e5" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>'
        />
        {/* Theme color for browser UI */}
        <meta name="theme-color" content="#4f46e5" />
      </Head>
      <body className="antialiased">
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
