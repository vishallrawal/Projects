import { useRouter } from 'next/router';
import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useAuth } from '../../context/AuthContext';
import { useModal } from '../../context/ModalContext';
import { Spinner } from '../../components/ui/Spinner';
import Link from 'next/link';

export default function ItemDetailPage() {
  const router = useRouter();
  const { id } = router.query;
  const { user, isAuthenticated, isAdmin, updateUser } = useAuth();
  const { showModal } = useModal();
  
  const [item, setItem] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [mainImage, setMainImage] = useState('');

  useEffect(() => {
    if (id) {
      fetchItem();
    }
  }, [id]);

  const fetchItem = async () => {
    setIsLoading(true);
    try {
        const response = await fetch(`/api/items/${id}`);
        if (!response.ok) throw new Error('Item not found');
        const itemData = await response.json();
        setItem(itemData);
        setMainImage(itemData.imageUrls?.[0] || '');
    } catch (error) {
        showModal(error.message);
        router.push('/');
    } finally {
        setIsLoading(false);
    }
  };

  const handleRedeem = async () => {
    if (!isAuthenticated) return showModal("You must be logged in to redeem items.");
    if (user.points < item.pointsValue) return showModal("You don't have enough points for this item. You can buy more from your dashboard.");
    if (user.id === item.uploaderId) return showModal("You cannot redeem your own item.");

    setIsProcessing(true);
    try {
        const response = await fetch('/api/items/redeem', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ itemId: item.id, buyerId: user.id }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.message);
        updateUser(data.user);
        showModal(`Success! You've redeemed "${item.title}".`);
        router.push('/dashboard');
    } catch (error) {
        showModal(`Error: ${error.message}`);
    } finally {
        setIsProcessing(false);
    }
  };

  const handleRelist = async () => {
    setIsProcessing(true);
    try {
        const response = await fetch('/api/items/relist', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ itemId: item.id, currentOwnerId: user.id }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.message);
        showModal(data.message);
        fetchItem(); // Refresh item data to show new status
    } catch (error) {
        showModal(`Error: ${error.message}`);
    } finally {
        setIsProcessing(false);
    }
  };

  if (isLoading || !item) {
    return (
        <>
            <Head><title>Loading Item... | ReWear</title></Head>
            <div className="h-screen flex items-center justify-center"><Spinner /></div>
        </>
    );
  }

  const pageTitle = `${item.title} | ReWear`;
  const pageDescription = item.description ? item.description.substring(0, 155) + '...' : 'A clothing item on ReWear.';
  const pageUrl = `http://localhost:3000/item/${item.id}`;
  const imageUrl = item.imageUrls?.[0] ? `http://localhost:3000${item.imageUrls[0]}` : '';

  const isOriginalOwner = user?.id === item.uploaderId;
  const isNewOwner = user?.id === item.newOwnerId;
  const isAvailable = item.status === 'available';
  const hasEnoughPoints = isAuthenticated && user.points >= item.pointsValue;
  const canEdit = isOriginalOwner || isAdmin;

  return (
    <>
        <Head>
            <title>{pageTitle}</title>
            <meta name="description" content={pageDescription} />
            <meta property="og:title" content={pageTitle} />
            <meta property="og:description" content={pageDescription} />
            <meta property="og:url" content={pageUrl} />
            <meta property="og:image" content={imageUrl} />
            <meta property="twitter:title" content={pageTitle} />
            <meta property="twitter:description" content={pageDescription} />
            <meta property="twitter:image" content={imageUrl} />
        </Head>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="bg-white p-4 md:p-8 rounded-xl shadow-lg">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Image Gallery */}
                    <div>
                        <div className="bg-gray-100 rounded-lg mb-4 h-96 flex items-center justify-center overflow-hidden">
                            <img src={mainImage || 'https://placehold.co/600x600/e2e8f0/cbd5e0?text=ReWear'} alt={item.title} className="max-w-full max-h-full object-contain rounded-lg"/>
                        </div>
                        <div className="grid grid-cols-4 gap-2">
                            {item.imageUrls?.map((url, index) => (
                                <div key={index} onClick={() => setMainImage(url)} className={`cursor-pointer rounded-md overflow-hidden border-2 ${mainImage === url ? 'border-indigo-500' : 'border-transparent'}`}>
                                    <img src={url} alt={`Thumbnail ${index+1}`} className="w-full h-24 object-cover" />
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Item Info */}
                    <div>
                        <div className="flex justify-between items-start">
                            <h1 className="text-4xl font-bold mb-2">{item.title}</h1>
                            <div className="text-3xl font-bold text-indigo-600">{item.pointsValue} <span className="text-lg font-medium">Points</span></div>
                        </div>
                        <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
                            <span>Category: <span className="font-semibold text-gray-700">{item.category}</span></span>
                            <span>Size: <span className="font-semibold text-gray-700">{item.size}</span></span>
                        </div>
                        <span className={`text-xs font-bold uppercase px-3 py-1.5 rounded-full ${item.condition === 'New' ? 'bg-blue-200 text-blue-800' : 'bg-green-200 text-green-800'}`}>{item.condition} Condition</span>
                        <p className="mt-6 text-gray-700 leading-relaxed">{item.description}</p>
                        <div className="mt-6 border-t pt-6">
                            <div className="flex items-center justify-between">
                                <p className="text-sm text-gray-500">Listed by</p>
                                <div className="font-semibold">{item.uploaderEmail}</div>
                            </div>
                            <div className="flex items-center justify-between mt-2">
                                <p className="text-sm text-gray-500">Status</p>
                                <div className={`font-semibold capitalize ${isAvailable ? 'text-green-600' : 'text-red-600'}`}>{item.status}</div>
                            </div>
                        </div>
                        {/* Action Buttons */}
                        <div className="mt-8 space-y-4">
                            {isAvailable && !isOriginalOwner && (
                                <div className="bg-indigo-50 p-6 rounded-lg">
                                    <button onClick={handleRedeem} disabled={isProcessing || !hasEnoughPoints} className="w-full py-3 px-4 text-white bg-indigo-600 rounded-md font-semibold hover:bg-indigo-700 disabled:bg-indigo-400 disabled:cursor-not-allowed">
                                        {isProcessing ? 'Processing...' : 'Redeem with Points'}
                                    </button>
                                    {!hasEnoughPoints && isAuthenticated && (<p className="text-center text-sm text-red-600 mt-3">You don't have enough points for this item.</p>)}
                                </div>
                            )}
                            {canEdit && <Link href={`/edit-item/${item.id}`} className="block w-full text-center bg-gray-200 text-gray-800 font-semibold py-3 px-4 rounded-lg hover:bg-gray-300">Edit Listing</Link>}
                            {isNewOwner && item.status === 'redeemed' && <button onClick={handleRelist} disabled={isProcessing} className="w-full bg-blue-500 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-600 disabled:bg-blue-300">{isProcessing ? 'Relisting...' : 'Relist This Item'}</button>}
                            {!isAvailable && !isNewOwner && !isOriginalOwner && <div className="text-center p-4 bg-red-100 text-red-700 rounded-lg font-semibold">This item is no longer available.</div>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>
  );
}
