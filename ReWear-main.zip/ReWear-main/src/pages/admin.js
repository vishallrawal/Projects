import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { useAuth } from '../context/AuthContext';
import { Spinner } from '../components/ui/Spinner';
import { EditUserModal } from '../components/admin/EditUserModal';
import { EditItemModal } from '../components/admin/EditItemModal';

export default function AdminPage() {
    const { isAdmin, loading } = useAuth();
    const router = useRouter();
    const [items, setItems] = useState([]);
    const [users, setUsers] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [view, setView] = useState('pending');
    const [editingUser, setEditingUser] = useState(null);
    const [editingItem, setEditingItem] = useState(null);

    useEffect(() => {
        if (!loading && !isAdmin) router.push('/');
        if (isAdmin) fetchAdminData();
    }, [isAdmin, loading, router]);

    const fetchAdminData = async () => {
        setIsLoading(true);
        try {
            const [itemsRes, usersRes] = await Promise.all([fetch('/api/admin/items'), fetch('/api/admin/users')]);
            const itemsData = await itemsRes.json();
            const usersData = await usersRes.json();
            setItems(Array.isArray(itemsData) ? itemsData : []);
            setUsers(Array.isArray(usersData) ? usersData : []);
        } catch (error) {
            console.error("Failed to fetch admin data:", error);
        }
        setIsLoading(false);
    };

    const handleItemUpdate = async (updateData) => {
        await fetch('/api/admin/items', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(updateData) });
        fetchAdminData();
        setEditingItem(null);
    };

    const handleUserDelete = async (userId) => {
        if (window.confirm('Are you sure you want to delete this user?')) {
            await fetch('/api/admin/users', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId }) });
            fetchAdminData();
        }
    };

    const handleUserUpdate = async (updatedUserData) => {
        await fetch('/api/admin/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(updatedUserData) });
        fetchAdminData();
        setEditingUser(null);
    };

    if (loading || isLoading) return <div className="h-screen w-full flex items-center justify-center"><Spinner /></div>;
    if (!isAdmin) return null;

    const filteredItems = items.filter(item => {
        if (view === 'pending') return item.status === 'pending';
        if (view === 'deleted') return item.status === 'deleted';
        if (view === 'all') return item.status !== 'deleted'; 
        return true;
    }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    return (
        <>
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <h1 className="text-4xl font-bold mb-6">Admin Panel</h1>
                <div className="bg-white p-6 rounded-xl shadow-lg">
                    <div className="border-b border-gray-200 mb-4">
                        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                            <button onClick={() => setView('pending')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${view === 'pending' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>Pending Items</button>
                            <button onClick={() => setView('all')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${view === 'all' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>All Items</button>
                            <button onClick={() => setView('deleted')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${view === 'deleted' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>Deleted Items</button>
                            <button onClick={() => setView('users')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${view === 'users' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>User Management</button>
                        </nav>
                    </div>
                    {view === 'users' ? <UserManagementTable users={users} onEdit={setEditingUser} onDelete={handleUserDelete} /> : <ItemManagementTable items={filteredItems} onUpdate={handleItemUpdate} onEdit={setEditingItem} />}
                </div>
            </div>
            {editingUser && <EditUserModal user={editingUser} onSave={handleUserUpdate} onClose={() => setEditingUser(null)} />}
            {editingItem && <EditItemModal item={editingItem} onSave={handleItemUpdate} onClose={() => setEditingItem(null)} />}
        </>
    );
}

const ItemManagementTable = ({ items, onUpdate, onEdit }) => (
    <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
                <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Item</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Featured</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
                {items.map(item => (
                    <tr key={item.id}>
                        <td className="px-6 py-4 whitespace-nowrap"><div className="flex items-center"><div className="flex-shrink-0 h-10 w-10"><img className="h-10 w-10 rounded-md object-cover" src={item.imageUrls[0]} alt={item.title} /></div><div className="ml-4"><div className="text-sm font-medium text-gray-900">{item.title}</div></div></div></td>
                        <td className="px-6 py-4 whitespace-nowrap"><span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.status === 'available' ? 'bg-green-100 text-green-800' : item.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'}`}>{item.status}</span></td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm"><button onClick={() => onUpdate({ itemId: item.id, isFeatured: !item.isFeatured })} className={`font-bold text-xl ${item.isFeatured ? 'text-yellow-500' : 'text-gray-300'}`}>★</button></td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            {item.status === 'pending' && <><button onClick={() => onUpdate({ itemId: item.id, status: 'available' })} className="text-indigo-600 hover:text-indigo-900 mr-4">Approve</button><button onClick={() => onUpdate({ itemId: item.id, status: 'rejected' })} className="text-red-600 hover:text-red-900">Reject</button></>}
                            <button onClick={() => onEdit(item)} className="text-gray-600 hover:text-gray-900 ml-4">Edit</button>
                            {item.status !== 'deleted' && <button onClick={() => onUpdate({ itemId: item.id, status: 'deleted' })} className="text-red-600 hover:text-red-900 ml-4">Delete</button>}
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
);

const UserManagementTable = ({ users, onEdit, onDelete }) => (
    <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
                <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
                {users.map(user => (
                    <tr key={user.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">{user.fullName}</div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${user.isAdmin ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                                {user.isAdmin ? 'Admin' : 'User'}
                            </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <Link href={`/admin/user/${user.id}`} className="text-green-600 hover:text-green-900 mr-4">View</Link>
                            <button onClick={() => onEdit(user)} className="text-indigo-600 hover:text-indigo-900 mr-4">Edit</button>
                            {!user.isAdmin && <button onClick={() => onDelete(user.id)} className="text-red-600 hover:text-red-900">Delete</button>}
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
);
