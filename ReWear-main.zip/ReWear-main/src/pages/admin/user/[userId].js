import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../../context/AuthContext';
import { Spinner } from '../../../components/ui/Spinner';
import ItemCard from '../../../components/ItemCard';

export default function AdminUserDetailPage() {
    const { isAdmin, loading: authLoading } = useAuth();
    const router = useRouter();
    const { userId } = router.query;
    const [userData, setUserData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!authLoading && !isAdmin) router.push('/');
        if (userId && isAdmin) fetchUserDetails();
    }, [userId, isAdmin, authLoading]);

    const fetchUserDetails = async () => {
        setIsLoading(true);
        try {
            const res = await fetch(`/api/users/${userId}/details`);
            if (!res.ok) throw new Error("Failed to fetch user details");
            setUserData(await res.json());
        } catch (error) {
            console.error(error);
            router.push('/admin');
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading || authLoading) return <div className="h-screen flex items-center justify-center"><Spinner /></div>;
    if (!userData) return <p>User not found.</p>;

    const { user, listedItems, soldItems, acquiredItems } = userData;

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <button onClick={() => router.push('/admin')} className="mb-6 text-indigo-600 hover:underline">← Back to Admin Panel</button>
            <div className="bg-white p-8 rounded-xl shadow-lg mb-8">
                <h1 className="text-3xl font-bold">{user.fullName}</h1>
                <p className="text-gray-600">{user.email}</p>
                <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm border-t pt-4">
                    <div><span className="font-semibold">User ID:</span> <span className="font-mono">{user.id}</span></div>
                    <div><span className="font-semibold">Phone:</span> {user.phoneNumber || 'N/A'}</div>
                    <div><span className="font-semibold">Points:</span> {user.points}</div>
                    <div><span className="font-semibold">Admin:</span> {user.isAdmin ? 'Yes' : 'No'}</div>
                    <div className="col-span-full"><span className="font-semibold">Address:</span> {user.shippingAddress || 'N/A'}</div>
                </div>
            </div>

            <div className="space-y-12">
                <section>
                    <h2 className="text-2xl font-bold mb-4">Items Listed ({listedItems.length})</h2>
                    {listedItems.length > 0 ? <div className="grid grid-cols-1 md:grid-cols-4 gap-6">{listedItems.map(item => <ItemCard key={item.id} item={item} />)}</div> : <p>No items listed by this user.</p>}
                </section>
                <section>
                    <h2 className="text-2xl font-bold mb-4">Items Sold ({soldItems.length})</h2>
                    {soldItems.length > 0 ? <div className="grid grid-cols-1 md:grid-cols-4 gap-6">{soldItems.map(item => <ItemCard key={item.id} item={item} />)}</div> : <p>No items sold by this user.</p>}
                </section>
                <section>
                    <h2 className="text-2xl font-bold mb-4">Items Acquired ({acquiredItems.length})</h2>
                    {acquiredItems.length > 0 ? <div className="grid grid-cols-1 md:grid-cols-4 gap-6">{acquiredItems.map(item => <ItemCard key={item.id} item={item} />)}</div> : <p>No items acquired by this user.</p>}
                </section>
            </div>
        </div>
    );
}
