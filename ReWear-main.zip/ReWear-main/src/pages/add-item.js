import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../context/AuthContext';
import { useModal } from '../context/ModalContext';
import { Icon } from '../components/ui/Icon';

export default function AddItemPage() {
    const { user, isAuthenticated, loading } = useAuth();
    const router = useRouter();
    const { showModal } = useModal();

    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [category, setCategory] = useState('Tops');
    const [size, setSize] = useState('M');
    const [condition, setCondition] = useState('Good');
    const [pointsValue, setPointsValue] = useState(10);
    const [images, setImages] = useState([]);
    const [imagePreviews, setImagePreviews] = useState([]);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (!loading && !isAuthenticated) {
            router.push('/login');
        }
    }, [isAuthenticated, loading, router]);
    
    const handleImageChange = (e) => {
        if (e.target.files) {
            const files = Array.from(e.target.files).slice(0, 4);
            setImages(files);
            const previews = files.map(file => URL.createObjectURL(file));
            setImagePreviews(previews);
        }
    };
    
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (images.length === 0) {
            showModal("Please upload at least one image.");
            return;
        }
        setIsSubmitting(true);

        const formData = new FormData();
        images.forEach(image => {
            formData.append('images', image);
        });

        try {
            const uploadResponse = await fetch('/api/upload', {
                method: 'POST',
                body: formData,
            });

            if (!uploadResponse.ok) {
                throw new Error('Image upload failed');
            }
            const uploadData = await uploadResponse.json();
            const imageUrls = uploadData.paths; 

            const newItemData = {
                title, description, category, size, condition,
                pointsValue: Number(pointsValue),
                imageUrls,
                uploaderId: user.id,
            };

            const itemResponse = await fetch('/api/items', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newItemData),
            });

            if (itemResponse.ok) {
                showModal("Item listed successfully! It's now pending admin approval.");
                router.push('/dashboard');
            } else {
                const errorData = await itemResponse.json();
                throw new Error(errorData.message || 'Failed to list item');
            }
        } catch (error) {
            showModal(`Submission failed: ${error.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (loading || !isAuthenticated) return null;

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-lg">
                <h1 className="text-3xl font-bold mb-6">List a New Item</h1>
                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Image Upload Section */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Upload Images (up to 4)</label>
                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                            <div className="space-y-1 text-center">
                                <Icon path="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" className="mx-auto h-12 w-12 text-gray-400" />
                                <div className="flex text-sm text-gray-600">
                                    <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                                        <span>Upload files</span>
                                        <input id="file-upload" name="file-upload" type="file" multiple accept="image/*" onChange={handleImageChange} className="sr-only" />
                                    </label>
                                    <p className="pl-1">or drag and drop</p>
                                </div>
                            </div>
                        </div>
                        {imagePreviews.length > 0 && (
                            <div className="mt-4 grid grid-cols-4 gap-4">
                                {imagePreviews.map((src, index) => <img key={index} src={src} alt="Preview" className="w-full h-24 object-cover rounded-md"/>)}
                            </div>
                        )}
                    </div>
                    {/* Item Details Form */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Title</label>
                            <input type="text" value={title} onChange={e => setTitle(e.target.value)} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Category</label>
                            <select value={category} onChange={e => setCategory(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option>Tops</option><option>Bottoms</option><option>Dresses</option><option>Outerwear</option><option>Accessories</option><option>Shoes</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Size</label>
                            <select value={size} onChange={e => setSize(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option>XS</option><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Condition</label>
                             <select value={condition} onChange={e => setCondition(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option>New</option><option>Like New</option><option>Good</option><option>Fair</option>
                            </select>
                        </div>
                        <div className="md:col-span-2">
                             <label className="block text-sm font-medium text-gray-700">Description</label>
                             <textarea value={description} onChange={e => setDescription(e.target.value)} rows="4" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"></textarea>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-700">Points Value</label>
                            <input type="number" value={pointsValue} onChange={e => setPointsValue(e.target.value)} required min="0" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
                        </div>
                    </div>
                    <div className="flex justify-end gap-4">
                        <button type="button" onClick={() => router.push('/dashboard')} className="py-2 px-6 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">Cancel</button>
                        <button type="submit" disabled={isSubmitting} className="py-2 px-6 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300">
                            {isSubmitting ? 'Submitting...' : 'Submit Item'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
