import '../styles/globals.css';
import Head from 'next/head';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { AuthProvider } from '../context/AuthContext';
import { ModalProvider } from '../context/ModalContext';

function MyApp({ Component, pageProps }) {
  const siteTitle = "ReWear - Community Clothing Exchange";
  const description = "Join the ReWear community to swap, share, and refresh your wardrobe sustainably. Reduce waste, save money, and discover unique styles.";
  const siteUrl = "http://localhost:3000"; // In production, change this to your actual domain

  return (
    <AuthProvider>
      <ModalProvider>
        <Head>
          {/* Default metadata for all pages */}
          <title>{siteTitle}</title>
          <meta name="description" content={description} />
          
          {/* Open Graph / Facebook */}
          <meta property="og:type" content="website" />
          <meta property="og:url" content={siteUrl} />
          <meta property="og:title" content={siteTitle} />
          <meta property="og:description" content={description} />
          {/* <meta property="og:image" content={`${siteUrl}/og-image.png`} /> */}

          {/* Twitter */}
          <meta property="twitter:card" content="summary_large_image" />
          <meta property="twitter:url" content={siteUrl} />
          <meta property="twitter:title" content={siteTitle} />
          <meta property="twitter:description" content={description} />
          {/* <meta property="twitter:image" content={`${siteUrl}/og-image.png`} /> */}
        </Head>
        <div className="bg-gray-50 min-h-screen font-sans text-gray-800 flex flex-col">
          <Navbar />
          <main className="pt-20 flex-grow">
            <Component {...pageProps} />
          </main>
          <Footer />
        </div>
      </ModalProvider>
    </AuthProvider>
  );
}

export default MyApp;
