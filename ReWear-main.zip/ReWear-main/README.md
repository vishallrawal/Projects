# ReWear - Local-First Clothing Exchange Platform
This is a full-stack web application for the ReWear project, a platform that allows users to list, manage, and redeem items in a clothing exchange. The entire application is designed to run locally without needing any external services.

It's built with Next.js, React, and Tailwind CSS. The backend is powered by Next.js API Routes, and it uses a simple local JSON file (/data/db.json) as its database.

Core Features
- *Full User Authentication*: Local user registration and login system.
- *Complete Item Management*: Users can list new items with image uploads, edit their listings, and redeem items from others using a points system.
- *Powerful Admin Panel*: An admin can manage all users and items, approve pending listings, and feature items on the homepage.
- *Local File-Based Backend*: The entire application is self-contained. The API and "database" run locally, making it perfect for offline development and testing.
- *Dynamic Frontend*: The UI is built with React and updates based on the data from the local API.

## Project Setup

First, install the necessary dependencies:

```bash
npm install
```

Then, start the development server:

```bash
npm run dev
```

Open your browser and navigate to [http://localhost:3000](http://localhost:3000) to view the app.

## Live Preview

A live preview of the frontend is available here: [rewear.shravangoswami.com](https://rewear.shravangoswami.com/)

> Important Note: This is a frontend-only preview to showcase the user interface. The backend API, which handles user registration, item creation, and all other dynamic features, is not active on this preview link. To use all features of the application, you must run the project locally as described in the setup instructions.

## Login Credentials

### Admin User
- Email: 
    ```
    admin@rewear.com
    ```
- Password: 
    ```
    admin123
    ```

### Test User
- Email: 
    ```
    test@gmail.com
    ```
- Password: 
    ```
    test123
    ```
You can also register new users directly from the login page.

## LICENSE
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

I just made this project out of boredom, I am licensing it under the MIT License. So you can use it as you wish, but I would appreciate it if you could give me credit for the work I have done. Happy hacking!

## Contributing
Contributions are welcome! If you find any bugs or have suggestions for improvements, feel free to open an issue or submit a pull request.

## Contact
For any questions or feedback, you can reach me at [shravanngoswamii@gmail.com](mailto:shravanngoswamii@gmail.com)