import formsPlugin from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
const config = {
  // Using a broader path to ensure all files in the src directory are scanned
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {},
  },
  // Registering the forms plugin to automatically style your form elements
  plugins: [
    formsPlugin,
  ],
};

export default config;
